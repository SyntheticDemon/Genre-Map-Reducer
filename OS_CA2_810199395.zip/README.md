# Genre-Map-Reducer
A map reducer for genres and proud literature
